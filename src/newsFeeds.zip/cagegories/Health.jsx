import React from 'react';

const Health = () => {
    return <div></div>;
}


export default Health;