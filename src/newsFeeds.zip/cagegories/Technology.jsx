import React from 'react';

const Technology = () => {
    return <div></div>;
}


export default Technology;