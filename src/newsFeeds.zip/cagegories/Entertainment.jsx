import React from 'react';

const Entertainment = () => {
    return <div></div>;
}


export default Entertainment;