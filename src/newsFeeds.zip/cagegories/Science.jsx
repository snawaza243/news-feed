import React from 'react';

const Science = () => {
    return <div></div>;
}


export default Science;