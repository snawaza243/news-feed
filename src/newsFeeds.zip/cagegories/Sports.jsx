import React from 'react';

const Sports = () => {
    return <div></div>;
}



export default Sports;