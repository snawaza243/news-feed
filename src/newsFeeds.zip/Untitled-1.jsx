value="AX" option =Aland Islands</optionvalue=>
value="AL" option =Albania</optionvalue=>
value="DZ" option =Algeria</optionvalue=>
value="AS" option =American Samoa</optionvalue=>
value="AD" option =Andorra</optionvalue=>
value="AO" option =Angola</optionvalue=>
value="AI" option =Anguilla</optionvalue=>
value="AQ" option =Antarctica</optionvalue=>
value="AG" option =Antigua and Barbuda</optionvalue=>
value="AR" option =Argentina</optionvalue=>
value="AM" option =Armenia</optionvalue=>
value="AW" option =Aruba</optionvalue=>
value="AU" option =Australia</optionvalue=>
value="AT" option =Austria</optionvalue=>
value="AZ" option =Azerbaijan</optionvalue=>
value="BS" option =Bahamas</optionvalue=>
value="BH" option =Bahrain</optionvalue=>
value="BD" option =Bangladesh</optionvalue=>
value="BB" option =Barbados</optionvalue=>
value="BY" option =Belarus</optionvalue=>
value="BE" option =Belgium</optionvalue=>
value="BZ" option =Belize</optionvalue=>
value="BJ" option =Benin</optionvalue=>
value="BM" option =Bermuda</optionvalue=>
value="BT" option =Bhutan</optionvalue=>
value="BO" option =Bolivia</optionvalue=>
value="BQ" option =Bonaire, Sint Eustatius and Saba</optionvalue=>
value="BA" option =Bosnia and Herzegovina</optionvalue=>
value="BW" option =Botswana</optionvalue=>
value="BV" option =Bouvet Island</optionvalue=>
value="BR" option =Brazil</optionvalue=>
value="IO" option =British Indian Ocean Territory</optionvalue=>
value="BN" option =Brunei Darussalam</optionvalue=>
value="BG" option =Bulgaria</optionvalue=>
value="BF" option =Burkina Faso</optionvalue=>
value="BI" option =Burundi</optionvalue=>
value="KH" option =Cambodia</optionvalue=>
value="CM" option =Cameroon</optionvalue=>
value="CA" option =Canada</optionvalue=>
value="CV" option =Cape Verde</optionvalue=>
value="KY" option =Cayman Islands</optionvalue=>
value="CF" option =Central African Republic</optionvalue=>
value="TD" option =Chad</optionvalue=>
value="CL" option =Chile</optionvalue=>
value="CN" option =China</optionvalue=>
value="CX" option =Christmas Island</optionvalue=>
value="CC" option =Cocos (Keeling) Islands</optionvalue=>
value="CO" option =Colombia</optionvalue=>
value="KM" option =Comoros</optionvalue=>
value="CG" option =Congo</optionvalue=>
value="CD" option =Congo, Democratic Republic of the Congo</optionvalue=>
value="CK" option =Cook Islands</optionvalue=>
value="CR" option =Costa Rica</optionvalue=>
value="CI" option =Cote D'Ivoire</optionvalue=>
value="HR" option =Croatia</optionvalue=>
value="CU" option =Cuba</optionvalue=>
value="CW" option =Curacao</optionvalue=>
value="CY" option =Cyprus</optionvalue=>
value="CZ" option =Czech Republic</optionvalue=>
value="DK" option =Denmark</optionvalue=>
value="DJ" option =Djibouti</optionvalue=>
value="DM" option =Dominica</optionvalue=>
value="DO" option =Dominican Republic</optionvalue=>
value="EC" option =Ecuador</optionvalue=>
value="EG" option =Egypt</optionvalue=>
value="SV" option =El Salvador</optionvalue=>
value="GQ" option =Equatorial Guinea</optionvalue=>
value="ER" option =Eritrea</optionvalue=>
value="EE" option =Estonia</optionvalue=>
value="ET" option =Ethiopia</optionvalue=>
value="FK" option =Falkland Islands (Malvinas)</optionvalue=>
value="FO" option =Faroe Islands</optionvalue=>
value="FJ" option =Fiji</optionvalue=>
value="FI" option =Finland</optionvalue=>
value="FR" option =France</optionvalue=>
value="GF" option =French Guiana</optionvalue=>
value="PF" option =French Polynesia</optionvalue=>
value="TF" option =French Southern Territories</optionvalue=>
value="GA" option =Gabon</optionvalue=>
value="GM" option =Gambia</optionvalue=>
value="GE" option =Georgia</optionvalue=>
value="DE" option =Germany</optionvalue=>
value="GH" option =Ghana</optionvalue=>
value="GI" option =Gibraltar</optionvalue=>
value="GR" option =Greece</optionvalue=>
value="GL" option =Greenland</optionvalue=>
value="GD" option =Grenada</optionvalue=>
value="GP" option =Guadeloupe</optionvalue=>
value="GU" option =Guam</optionvalue=>
value="GT" option =Guatemala</optionvalue=>
value="GG" option =Guernsey</optionvalue=>
value="GN" option =Guinea</optionvalue=>
value="GW" option =Guinea-Bissau</optionvalue=>
value="GY" option =Guyana</optionvalue=>
value="HT" option =Haiti</optionvalue=>
value="HM" option =Heard Island and Mcdonald Islands</optionvalue=>
value="VA" option =Holy See (Vatican City State)</optionvalue=>
value="HN" option =Honduras</optionvalue=>
value="HK" option =Hong Kong</optionvalue=>
value="HU" option =Hungary</optionvalue=>
value="IS" option =Iceland</optionvalue=>
value="IN" option = >India</optionvalue=>
value="ID" option =Indonesia</optionvalue=>
value="IR" option =Iran, Islamic Republic of</optionvalue=>
value="IQ" option =Iraq</optionvalue=>
value="IE" option =Ireland</optionvalue=>
value="IM" option =Isle of Man</optionvalue=>
value="IL" option =Israel</optionvalue=>
value="IT" option =Italy</optionvalue=>
value="JM" option =Jamaica</optionvalue=>
value="JP" option =Japan</optionvalue=>
value="JE" option =Jersey</optionvalue=>
value="JO" option =Jordan</optionvalue=>
value="KZ" option =Kazakhstan</optionvalue=>
value="KE" option =Kenya</optionvalue=>
value="KI" option =Kiribati</optionvalue=>
value="KP" option =Korea, Democratic People's Republic of</optionvalue=>
value="KR" option =Korea, Republic of</optionvalue=>
value="XK" option =Kosovo</optionvalue=>
value="KW" option =Kuwait</optionvalue=>
value="KG" option =Kyrgyzstan</optionvalue=>
value="LA" option =Lao People's Democratic Republic</optionvalue=>
value="LV" option =Latvia</optionvalue=>
value="LB" option =Lebanon</optionvalue=>
value="LS" option =Lesotho</optionvalue=>
value="LR" option =Liberia</optionvalue=>
value="LY" option =Libyan Arab Jamahiriya</optionvalue=>
value="LI" option =Liechtenstein</optionvalue=>
value="LT" option =Lithuania</optionvalue=>
value="LU" option =Luxembourg</optionvalue=>
value="MO" option =Macao</optionvalue=>
value="MK" option =Macedonia, the Former Yugoslav Republic </optionvalue=>
value="MG" option =Madagascar</optionvalue=>
value="MW" option =Malawi</optionvalue=>
value="MY" option =Malaysia</optionvalue=>
value="MV" option =Maldives</optionvalue=>
value="ML" option =Mali</optionvalue=>
value="MT" option =Malta</optionvalue=>
value="MH" option =Marshall Islands</optionvalue=>
value="MQ" option =Martinique</optionvalue=>
value="MR" option =Mauritania</optionvalue=>
value="MU" option =Mauritius</optionvalue=>
value="YT" option =Mayotte</optionvalue=>
value="MX" option =Mexico</optionvalue=>
value="FM" option =Micronesia, Federated States of</optionvalue=>
value="MD" option =Moldova, Republic of</optionvalue=>
value="MC" option =Monaco</optionvalue=>
value="MN" option =Mongolia</optionvalue=>
value="ME" option =Montenegro</optionvalue=>
value="MS" option =Montserrat</optionvalue=>
value="MA" option =Morocco</optionvalue=>
value="MZ" option =Mozambique</optionvalue=>
value="MM" option =Myanmar</optionvalue=>
value="NA" option =Namibia</optionvalue=>
value="NR" option =Nauru</optionvalue=>
value="NP" option =Nepal</optionvalue=>
value="NL" option =Netherlands</optionvalue=>
value="AN" option =Netherlands Antilles</optionvalue=>
value="NC" option =New Caledonia</optionvalue=>
value="NZ" option =New Zealand</optionvalue=>
value="NI" option =Nicaragua</optionvalue=>
value="NE" option =Niger</optionvalue=>
value="NG" option =Nigeria</optionvalue=>
value="NU" option =Niue</optionvalue=>
value="NF" option =Norfolk Island</optionvalue=>
value="MP" option =Northern Mariana Islands</optionvalue=>
value="NO" option =Norway</optionvalue=>
value="OM" option =Oman</optionvalue=>
value="PK" option =Pakistan</optionvalue=>
value="PW" option =Palau</optionvalue=>
value="PS" option =Palestinian Territory, Occupied</optionvalue=>
value="PA" option =Panama</optionvalue=>
value="PG" option =Papua New Guinea</optionvalue=>
value="PY" option =Paraguay</optionvalue=>
value="PE" option =Peru</optionvalue=>
value="PH" option =Philippines</optionvalue=>
value="PN" option =Pitcairn</optionvalue=>
value="PL" option =Poland</optionvalue=>
value="PT" option =Portugal</optionvalue=>
value="PR" option =Puerto Rico</optionvalue=>
value="QA" option =Qatar</optionvalue=>
value="RE" option =Reunion</optionvalue=>
value="RO" option =Romania</optionvalue=>
value="RU" option =Russian Federation</optionvalue=>
value="RW" option =Rwanda</optionvalue=>
value="BL" option =Saint Barthelemy</optionvalue=>
value="SH" option =Saint Helena</optionvalue=>
value="KN" option =Saint Kitts and Nevis</optionvalue=>
value="LC" option =Saint Lucia</optionvalue=>
value="MF" option =Saint Martin</optionvalue=>
value="PM" option =Saint Pierre and Miquelon</optionvalue=>
value="VC" option =Saint Vincent and the Grenadines</optionvalue=>
value="WS" option =Samoa</optionvalue=>
value="SM" option =San Marino</optionvalue=>
value="ST" option =Sao Tome and Principe</optionvalue=>
value="SA" option =Saudi Arabia</optionvalue=>
value="SN" option =Senegal</optionvalue=>
value="RS" option =Serbia</optionvalue=>
value="CS" option =Serbia and Montenegro</optionvalue=>
value="SC" option =Seychelles</optionvalue=>
value="SL" option =Sierra Leone</optionvalue=>
value="SG" option =Singapore</optionvalue=>
value="SX" option =Sint Maarten</optionvalue=>
value="SK" option =Slovakia</optionvalue=>
value="SI" option =Slovenia</optionvalue=>
value="SB" option =Solomon Islands</optionvalue=>
value="SO" option =Somalia</optionvalue=>
value="ZA" option =South Africa</optionvalue=>
value="GS" option =South Georgia and the South Sandwich </optionvalue=>
value="SS" option =South Sudan</optionvalue=>
value="ES" option =Spain</optionvalue=>
value="LK" option =Sri Lanka</optionvalue=>
value="SD" option =Sudan</optionvalue=>
value="SR" option =Suriname</optionvalue=>
value="SJ" option =Svalbard and Jan Mayen</optionvalue=>
value="SZ" option =Swaziland</optionvalue=>
value="SE" option =Sweden</optionvalue=>
value="CH" option =Switzerland</optionvalue=>
value="SY" option =Syrian Arab Republic</optionvalue=>
value="TW" option =Taiwan, Province of China</optionvalue=>
value="TJ" option =Tajikistan</optionvalue=>
value="TZ" option =Tanzania, United Republic of</optionvalue=>
value="TH" option =Thailand</optionvalue=>
value="TL" option =Timor-Leste</optionvalue=>
value="TG" option =Togo</optionvalue=>
value="TK" option =Tokelau</optionvalue=>
value="TO" option =Tonga</optionvalue=>
value="TT" option =Trinidad and Tobago</optionvalue=>
value="TN" option =Tunisia</optionvalue=>
value="TR" option =Turkey</optionvalue=>
value="TM" option =Turkmenistan</optionvalue=>
value="TC" option =Turks and Caicos Islands</optionvalue=>
value="TV" option =Tuvalu</optionvalue=>
value="UG" option =Uganda</optionvalue=>
value="UA" option =Ukraine</optionvalue=>
value="AE" option =United Arab Emirates</optionvalue=>
value="GB" option =United Kingdom</optionvalue=>
value="US" option =United States</optionvalue=>
value="UM" option =United States Minor Outlying Islands</optionvalue=>
value="UY" option =Uruguay</optionvalue=>
value="UZ" option =Uzbekistan</optionvalue=>
value="VU" option =Vanuatu</optionvalue=>
value="VE" option =Venezuela</optionvalue=>
value="VN" option =Viet Nam</optionvalue=>
value="VG" option =Virgin Islands, British</optionvalue=>
value="VI" option =Virgin Islands, U.s.</optionvalue=>
value="WF" option =Wallis and Futuna</optionvalue=>
value="EH" option =Western Sahara</optionvalue=>
value="YE" option =Yemen</optionvalue=>
value="ZM" option =Zambia</optionvalue=>
value="ZW" option =Zimbabwe</optionvalue=>