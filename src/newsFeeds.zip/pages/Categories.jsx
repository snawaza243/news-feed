import React from 'react'

export const Categories = ({cat}) => {
  return (
    <div className='' style={{minHeight:"100vh"}}>{cat}</div>
  )
}
